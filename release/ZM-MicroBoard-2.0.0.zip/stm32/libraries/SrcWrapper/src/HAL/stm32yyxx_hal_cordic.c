#ifdef STM32G4xx
  #include "stm32g4xx_hal_cordic.c"
#endif
#ifdef STM32H7xx
  #include "stm32h7xx_hal_cordic.c"
#endif
