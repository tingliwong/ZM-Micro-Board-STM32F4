#ifdef STM32F3xx
  #include "stm32f3xx_hal_sdadc.c"
#endif
