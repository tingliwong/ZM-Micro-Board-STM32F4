# Arduino_Tools
[![GitHub release](https://img.shields.io/github/release/stm32duino/Arduino_Tools.svg)](https://github.com/stm32duino/Arduino_Tools/releases/latest)
[![GitHub commits](https://img.shields.io/github/commits-since/stm32duino/Arduino_Tools/1.4.0.svg)](https://github.com/stm32duino/Arduino_Tools/compare/1.4.0...master)

Contains upload tools for STM32 based boards and some other usefull scripts.
