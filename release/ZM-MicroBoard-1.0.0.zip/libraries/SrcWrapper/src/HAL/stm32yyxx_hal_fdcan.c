#ifdef STM32G4xx
  #include "stm32g4xx_hal_fdcan.c"
#endif
#ifdef STM32H7xx
  #include "stm32h7xx_hal_fdcan.c"
#endif
#ifdef STM32L5xx
  #include "stm32l5xx_hal_fdcan.c"
#endif
#ifdef STM32MP1xx
  #include "stm32mp1xx_hal_fdcan.c"
#endif
