#ifdef STM32F4xx
  #include "stm32f4xx_hal_fmpsmbus_ex.c"
#endif
